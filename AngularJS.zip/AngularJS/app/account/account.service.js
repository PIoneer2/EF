'use strict';

angular
.module('transactionsMainApp')
.service('accountHttpService', accountHttpService);

accountHttpService.$inject = ['$http', '$httpParamSerializerJQLike', '$location'];
function accountHttpService (typeOfService, data, redirectPath, $http, $httpParamSerializerJQLike, $location){
    //self.showRegMessage = true;
this.makePOST = function(URL, Id) {
var 
URLReg = 'http://localhost/efapi/api/Account/Register',
URLLogin = 'http://localhost/efapi/token',
URL, sendData, header, redirect = redirectPath;

if (typeOfService == 'reg'){
    URL = URLReg;
    sendData = $httpParamSerializerJQLike(data);
    headers = {};
}
else { //typeOfService == 'login'
    URL = URLLogin;
    sendData = data;
    header = { 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8' };
}

return $http({method: 'POST', url: URL, data: sendData, headers: header})
.then(
    function(response) {
      self.serverMessage = response.Message;
      if (typeOfService == 'reg'){
        sessionStorage.userName = self.email;
      }
      else {
        sessionStorage.userName = response.data.userName;
        sessionStorage.token = response.data.access_token;
        sessionStorage.Id = response.data.Id;
        $rootScope.email = sessionStorage.userName;
        $rootScope.token = sessionStorage.token;
        $rootScope.logged = true;
      }  
      $timeout(function() {
        self.showServerMessage = false;
        $location.path(redirect);
    }, 2000);
  },
  function (response) {
    try {
        self.serverMessage = response.data.Message;
        self.modelErrors = new Array();
        for (var key in response.data.ModelState) {
            for (var i = 0; i < response.data.ModelState[key].length; i++) {
                self.modelErrors.push(response.data.ModelState[key][i]);
            }
        }
    }
    catch (error) {
        self.serverMessage = error.data;
    }
    finally {
        $timeout(function() {
            self.showServerMessage = false;
        }, 5000);
    }
});
    }
    return this;
};