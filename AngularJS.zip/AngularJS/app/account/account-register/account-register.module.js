'use strict';

angular.module('accountRegister', []);
