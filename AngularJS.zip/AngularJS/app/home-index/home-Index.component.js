'use strict';

angular.
  module('homeIndex').
  component('homeIndex', {
  templateUrl: 'home-index/home-index.template.html',
  controller: ['$routeParams', '$http',
  function HomeIndexController($routeParams, $http) {
    
  }]    
});
