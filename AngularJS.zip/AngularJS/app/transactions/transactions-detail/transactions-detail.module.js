'use strict';

// Define the `transactionsDetail` module
angular.module('transactionsDetail', [
	'ngRoute'
	]);
