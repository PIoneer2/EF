'use strict';

// Define the `transactionsList` module
angular.module('transactionsList', []);
