'use strict';

// Define the `transactionsCreateedit` module
angular.module('transactionsCreateedit', [
	'ngRoute'
	]);
