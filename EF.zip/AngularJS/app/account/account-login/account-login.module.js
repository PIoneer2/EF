'use strict';

angular.module('accountLogin', []);
