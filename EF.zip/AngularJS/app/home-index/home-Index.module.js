'use strict';

angular.module('homeIndex', []);
