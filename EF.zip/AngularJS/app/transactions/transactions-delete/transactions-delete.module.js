'use strict';

// Define the `transactionsDelete` module
angular.module('transactionsDelete', [
	'ngRoute'
	]);
