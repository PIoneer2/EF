﻿using EF.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Web;

namespace EF.WebApi.Models
{
    // Models used as incoming parameters to Entity Controllers actions.
    //[TypeConverter(typeof(TransactionDTOConverter))]

}